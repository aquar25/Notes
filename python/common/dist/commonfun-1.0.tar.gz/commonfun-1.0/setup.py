#!/usr/bin/env python
# -*- coding:utf-8 -*-

from setuptools import setup

# call the setup() function
setup(
    name='commonfun',
    version='1.0',
    description='Common functions',
    author='myname',
    author_email='myemail@mail.com',
    url='xxx.com',
    py_modules=['commonfun'], # a list of '.py' files to include in the package.
    )
